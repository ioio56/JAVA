package leejayoung.submit12;

public class CartoonBoard extends Board {
	String img;
	
	public CartoonBoard(int no, String title, String day, String content) {
		super(no, title, day, content);
	}


}
