package leejayoung.submit12;

public class AudioBoard extends Board {
	String audio;
	
	public AudioBoard(int no, String title, String day, String content) {
		super(no, title, day, content);
	}


	
}
